# my_lambdata_terrainthesky35

-----------


Datetimeextrator class can be imported and you can then use the 
datetimeconversion to extract the year, month, and day and spit out a dataframe called datetime_df.

Parameters: pandas datetime dataframe


Train_val_test_splitter can be imported as train_test_wrangle.
It takes in your data and your target data as parameters and returns X_train, y_train, X_val, y_val, X_test, y_test at a 80/20/20 split respectively.

Parameters: pandas dataframe (X), target (y)


